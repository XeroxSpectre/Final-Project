package com.example.finalproject;

public class Interface {
    private String option1;
    private String option2;

    String[] overwhelmed = new String[3];
    String[] stressed = new String[3];
    String[] depressed = new String[3];
    String[] lonely = new String[3];
    String[] angry = new String[3];
    String[] unmotivated = new String[3];
    String[] mediocre = new String[3];
    String[] alright = new String[3];
    String[] decent = new String[3];
    String[] content = new String[3];
    String[] relaxed = new String[3];
    String[] good = new String[3];
    String[] excited = new String[3];
    String[] happy = new String[3];
    String[] ecstatic = new String[3];

    String[] wayTooLate = new String[3];
    String[] earlyMorning = new String[3];
    String[] morning = new String[3];
    String[] aroundNoon = new String[3];
    String[] afterNoon = new String[3];
    String[] evening = new String[3];
    String[] night = new String[3];
    String[] aLittleLate = new String[3];

    public String getOption1() {
        return option1;
    }

    public void setOption1(String option1) {
        this.option1 = option1;
    }

    public String getOption2() {
        return option2;
    }

    public void setOption2(String option2) {
        this.option2 = option2;
    }

}




