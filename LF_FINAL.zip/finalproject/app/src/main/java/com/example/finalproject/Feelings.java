package com.example.finalproject;

public enum Feelings {
    Overwhelmed, Stressed, Depressed, Lonely, Angry, Unmotivated,
    Mediocre, Alright, Decent, Content, Relaxed,
    Good, Excited, Happy, Ecstatic
}
