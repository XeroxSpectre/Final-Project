package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    TextView textViewFeeling, editTextFeeling, textViewTime, editTextTime, editTextAMPM, textViewOutput, textViewList;
    Interface intFace = new Interface();
    private final int NEXT_PROMPT = 3;
    private int tryAgainCounter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        listFeelings();
        ;

    }


    public void fillArrays() {
        intFace.overwhelmed[0] = "Cheer up. Each day is a new day, don't let a an overwhelming moment change that";
        intFace.overwhelmed[1] = "It'll all be okay, things tend to get better";
        intFace.overwhelmed[2] = "Keep your head up, it's alright";

        intFace.stressed[0] = "Stress is normal, but make sure you don't let it control you";
        intFace.stressed[1] = "Take a deep breath. Go outside, go for a walk, relax";
        intFace.stressed[2] = "make sure you give yourself plenty of time to rest";

        intFace.depressed[0] = "It's okay to be sad sometimes, but if you wallow you only hurt yourself";
        intFace.depressed[1] = "Time never stops ticking. Pick yourself up and keep moving";
        intFace.depressed[2] = "It's okay to be upset, but make sure you keep a level head";

        intFace.lonely[0] = "You miss every shot you don't take. reach out to those you want to be friends with";
        intFace.lonely[1] = "Sometimes people do better by themselves. View today as a day for yourself";
        intFace.lonely[2] = "Take today and/or to reconnect past relationships that may have been severed";

        intFace.angry[0] = "Take that anger and turn it into determination";
        intFace.angry[1] = "Take some deep breaths, it's okay to get angry but don't hurt anyone";
        intFace.angry[2] = "Go to the gym, use anger for you to get STRONK";

        intFace.unmotivated[0] = "It's okay to be unmotivated sometimes, but you gotta be responsible too";
        intFace.unmotivated[1] = "Above all else, make sure you take care of yourself today";
        intFace.unmotivated[2] = "Just get some rest, maybe call a loved one and let them cheer you on";

        intFace.mediocre[0] = "Take today to reflect on what you like / what you dislike about your surroundings";
        intFace.mediocre[1] = "It could be worse. be thankful for that";
        intFace.mediocre[2] = "Try to better yourself and those around you today";

        intFace.alright[0] = "Things could be worse, always keep that in mind";
        intFace.alright[1] = "Spend today helping those around you that may be sad cheer up";
        intFace.alright[2] = "Keep your chin up and always remember to smile";

        intFace.decent[0] = "Make sure you don't let anything ruin your mood";
        intFace.decent[1] = "Keep up the good work! you got this";
        intFace.decent[2] = "Be sure to make time for yourself, regardless of how you're doing";

        intFace.content[0] = "Help others with their problems, everyone has the potential to help";
        intFace.content[1] = "Smile so those around you feel comfortable and safe enough to smile too";
        intFace.content[2] = "Strive for the top today, shoot for the stars";

        intFace.relaxed[0] = "Take a breather, today is for you";
        intFace.relaxed[1] = "Take today one step at a time, no need to rush things";
        intFace.relaxed[2] = "Remember to go with the flow";

        intFace.good[0] = "Spend today reaching out to those who look like they need a helping hand";
        intFace.good[1] = "Spend today making the environment better for those around you";
        intFace.good[2] = "Don't let anyone kill your vibe today";

        intFace.excited[0] = "Don't let the hope of the future blind your present";
        intFace.excited[1] = "Excitement is good, but remember to stay focused";
        intFace.excited[2] = "Don't lose your head out there. After all, you aren't a skeleton";

        intFace.happy[0] = "don't let negativity weigh you down";
        intFace.happy[1] = "don't let the bad days ruin this good day for yourself";
        intFace.happy[2] = "don't let yourself fall into stress today, ride the momentum";

        intFace.ecstatic[0] = "good to hear you're doing good. shoot for the stars today!";
        intFace.ecstatic[1] = "help out today, share the love!";
        intFace.ecstatic[2] = "make sure your pearly whites are on display today, good-lookin";

        intFace.wayTooLate[0] = "you need to lay down and shut your brain off, fool.";
        intFace.wayTooLate[1] = "drink some warm milk and head to bed.";
        intFace.wayTooLate[2] = "you should try and relax until you have to be up in the morning.";

        intFace.earlyMorning[0] = "go for a jog, while you still have the time.";
        intFace.earlyMorning[1] = "go look at the sunrise if it hasn't happened yet.";
        intFace.earlyMorning[2] = "watch some funny cat videos to start the day off right.";

        intFace.morning[0] = "take a shower and get ready for the day.";
        intFace.morning[1] = "make sure you don't lay around for too long and get lazy.";
        intFace.morning[2] = "make sure to eat breakfast.";

        intFace.aroundNoon[0] = "if you had class and didn't go, shame on you.";
        intFace.aroundNoon[1] = "eat a good lunch today.";
        intFace.aroundNoon[2] = "enjoy the afternoon today.";

        intFace.afterNoon[0] = "be thankful that you have the rest of the day, at least.";
        intFace.afterNoon[1] = "have a good rest of your day, regardless of the morning.";
        intFace.afterNoon[2] = "enjoy the weather, albeit it be good or bad weather is always beautiful.";

        intFace.evening[0] = "try and catch the sunset if you still can.";
        intFace.evening[1] = "make sure you at least eat a good dinner.";
        intFace.evening[2] = "enjoy the night, have some time for yourself.";

        intFace.night[0] = "maybe consider turning in early tonight.";
        intFace.night[1] = "think about putting your phone down and lying down.";
        intFace.night[2] = "try meditating for a few minutes.";

        intFace.aLittleLate[0] = "maybe start thinking about heading to bed.";
        intFace.aLittleLate[1] = "turn off the lights and close your eyes and try drifting off to sleep.";
        intFace.aLittleLate[2] = "hit that deadline tonight, you still have time!";


    }

    public void initView() {
        textViewFeeling = findViewById(R.id.textViewFeeling);
        editTextFeeling = findViewById(R.id.editTextFeeling);
        textViewTime = findViewById(R.id.textViewTime);
        editTextTime = findViewById(R.id.editTextTime);
        editTextAMPM = findViewById(R.id.editTextAMPM);
        textViewOutput = findViewById(R.id.textViewOutput);
        textViewList = findViewById(R.id.textViewList);
    }

    public void listFeelings() {
        textViewList.setText("These are the Emotions you can use: \n" + "\n" + "Overwhelmed \n" + "Stressed \n" + "Depressed \n" + "Lonely \n" + "Angry \n" + "Unmotivated \n" +
                "Mediocre \n" + "Alright \n" + "Decent \n" + "Content \n" + "Relaxed \n" +
                "Good \n" + "Excited \n" + "Happy \n" + "Ecstatic \n");
    }

    public boolean isAMOrPM() {
        if (editTextAMPM.getText().toString().equals("AM")) {
            return true;
        } else if (editTextAMPM.getText().toString().equals("PM")) {
            return false;
        } else {
            throw new IllegalArgumentException("Invalid Input");
        }
    }

    public String setOptionOne() {
        fillArrays();
        Random random = new Random();
        switch (editTextFeeling.getText().toString()) {
            case "Overwhelmed":
                intFace.setOption1(intFace.overwhelmed[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Stressed":
                intFace.setOption1(intFace.stressed[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Depressed":
                intFace.setOption1(intFace.depressed[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Lonely":
                intFace.setOption1(intFace.lonely[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Angry":
                intFace.setOption1(intFace.angry[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Unmotivated":
                intFace.setOption1(intFace.unmotivated[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Mediocre":
                intFace.setOption1(intFace.mediocre[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Alright":
                intFace.setOption1(intFace.alright[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Decent":
                intFace.setOption1(intFace.decent[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Content":
                intFace.setOption1(intFace.content[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Relaxed":
                intFace.setOption1(intFace.relaxed[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Good":
                intFace.setOption1(intFace.good[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Excited":
                intFace.setOption1(intFace.excited[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Happy":
                intFace.setOption1(intFace.happy[random.nextInt(NEXT_PROMPT)]);
                break;
            case "Ecstatic":
                intFace.setOption1(intFace.ecstatic[random.nextInt(NEXT_PROMPT)]);
                break;
        }
        return "broke";
    }
    public void setOptionTwo() {
        fillArrays();
        Random rando2 = new Random();
        if (editTextTime.getText().toString().equals("1") || editTextTime.getText().toString().equals("2") || editTextTime.getText().toString().equals("3")) {
            if (isAMOrPM() == true) {
                intFace.setOption2(intFace.wayTooLate[rando2.nextInt(NEXT_PROMPT)]);

            } else if (isAMOrPM() == false) {
                intFace.setOption2(intFace.afterNoon[rando2.nextInt(NEXT_PROMPT)]);
            }

        } else if(editTextTime.getText().toString().equals("4") || editTextTime.getText().toString().equals("5") || editTextTime.getText().toString().equals("6")){
            if (isAMOrPM() == true){
                intFace.setOption2(intFace.earlyMorning[rando2.nextInt(NEXT_PROMPT)]);
            } else if(isAMOrPM() == false){
                intFace.setOption2(intFace.evening[rando2.nextInt(NEXT_PROMPT)]);
            }
        }else if(editTextTime.getText().toString().equals("7") || editTextTime.getText().toString().equals("8") || editTextTime.getText().toString().equals("9")) {
            if (isAMOrPM() == true) {
                intFace.setOption2(intFace.morning[rando2.nextInt(NEXT_PROMPT)]);
            } else if (isAMOrPM() == false) {
                intFace.setOption2(intFace.night[rando2.nextInt(NEXT_PROMPT)]);
            }
        }else if(editTextTime.getText().toString().equals("10") || editTextTime.getText().toString().equals("11") || editTextTime.getText().toString().equals("12")){
            if (isAMOrPM() == true){
                intFace.setOption2(intFace.aroundNoon[rando2.nextInt(NEXT_PROMPT)]);
            } else if(isAMOrPM() == false){
                intFace.setOption2(intFace.aLittleLate[rando2.nextInt(NEXT_PROMPT)]);
            }
        }
    }

    public void onGenerate(View v){
        setOptionOne();
        setOptionTwo();
        textViewOutput.setText(intFace.getOption1() + ", And " + intFace.getOption2());



    }
    public void tryAgain(View v) {
        setOptionOne();
        setOptionTwo();
        textViewOutput.setText(intFace.getOption1() + ". " + intFace.getOption2());
        tryAgainCounter++;
        if (tryAgainCounter == 7) {
            editTextTime.setText("");
            editTextAMPM.setText("");
            editTextFeeling.setText("");
            textViewOutput.setText("Look, if you're desperately in need of help, you shouldn't be going to an app. I really recommend you go see a therapist. Neumont offers help through Blomquist Hale, i suggest you check them out if you need help.");
            tryAgainCounter = 0;

        }
    }
}