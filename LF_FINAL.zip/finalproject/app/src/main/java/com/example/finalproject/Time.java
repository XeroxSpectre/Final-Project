package com.example.finalproject;

public class Time {
    String timeAM;
    String timePM;
    Time[] time = new Time[12];



}
